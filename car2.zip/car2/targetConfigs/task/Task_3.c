#include "ti_msp_dl_config.h"
#include "Task_3.h"
#include "Task_1.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Trace.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Encoder.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\OLED.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Motor.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Pid.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\timer.h"  

extern uint8_t Trace_Value[8];

CAR_STATETypeDef CAR_SATE;

typedef enum {
    STATE_START_UP_3,     // 0 ~ 50脉冲：速度 10 → 350
    STATE_CRUISE_3,       // 50 ~ 100脉冲：保持 350
    STATE_SLOW_DOWN_3,    // 100 ~ 150脉冲：速度 350 → 10
    STATE_STOP_3          // 达到 150脉冲：停车锁死
} CarRunState_3_t;

CarRunState_3_t RunState_3 = STATE_START_UP_3;
uint8_t Exit_Confirm_3 = 0;
uint8_t Stop_Confirm_3 = 0;
uint8_t Align_Count_3 = 0;

uint32_t Final_Time_ms_3 = 0;   
uint32_t Total_Pulse_3 = 0;  
uint8_t  Ramp_Count_3 = 0;       
uint8_t  Slow_Down_Steps_3 = 0; 
#define SLOW_DOWN_TOTAL_STEPS_3 20  

PID_t PID_Trace_3 = {
     .PID_Float.Kp = 2.6 ,
    .PID_Float.Ki = 0.0,
    .PID_Float.Kd = 3.0 ,

    .PID_Int.OutMax = 351,
    .PID_Int.OutMin = -351
};
void Task_3_Init(void) {
    CAR_SATE = TRACE_SATE;
    RunState_3 = STATE_START_UP_3;
    Exit_Confirm_3 = 0;
    Stop_Confirm_3 = 0;
    Align_Count_3 = 0;
    Ramp_Count_3 = 0;
    Slow_Down_Steps_3 = 0;
    PID_Init(&PID_Trace_3);
    Motor_Shake();
    
    Timer_Reset();
    Final_Time_ms_3 = 0;
    Total_Pulse_3 = 0;
}

void Task_3_Loop(void) {
    Trace_GetValue();

    if (RunState_3 == STATE_STOP_3) {
        Motor_Shake();
        
        // 【致命修复】清空 PID 控制变量，彻底切断输出
        PID_Trace_3.PID_Int.Error0 = 0;
        PID_Trace_3.PID_Int.Error1 = 0;
        PID_Trace_3.PID_Int.ErrorInt = 0;
        PID_Trace_3.PID_Int.Out = 0;

        uint32_t real_time_ms = (Final_Time_ms_3 * 100) / 1256;
        if (real_time_ms > 999999) real_time_ms = 999999;
        OLED_ShowString(4, 1, "Time:");
        OLED_ShowNum(4, 5, real_time_ms, 6);
        OLED_ShowString(4, 11, "ms");

        // 【致命修复】强制死循环，永远不再进入下一轮循环
        while(1) { }
    }

    if (RunState_3 != STATE_STOP_3) {
        Total_Pulse_3 += Encoder_Get_Distance();
    }

    OLED_ShowNum(3, 11, Total_Pulse_3, 5);

    uint8_t all_black = 1;
    for (uint8_t i = 0; i < 8; i++) {
        if (Trace_Value[i] == 0) {
            all_black = 0; 
            break;
        }
    }

    switch (RunState_3) {
        
        case STATE_START_UP_3:
            if (!all_black) {
                Exit_Confirm_3++;
                if (Exit_Confirm_3 >= 2) {
                    Timer_Reset();
                    Exit_Confirm_3 = 0;
                }
            } else {
                Exit_Confirm_3 = 0;
            }

            PID_Trace_Update(&PID_Trace_3);

            if (Ramp_Count_3 < 50) { 
                Ramp_Count_3++;
                uint16_t speed = 10 + Ramp_Count_3 * (340 / 50); 
                if (speed > 350) speed = 350;
                Motor_SetSpeed(speed - PID_Trace_3.PID_Int.Out,
                               speed + PID_Trace_3.PID_Int.Out);
            }

            if (Total_Pulse_3 >= 50) {
                RunState_3 = STATE_CRUISE_3;
                Ramp_Count_3 = 0;
            }
            break;

        case STATE_CRUISE_3:
            PID_Trace_Update(&PID_Trace_3);
            Motor_SetSpeed(350 - PID_Trace_3.PID_Int.Out,
                           350 + PID_Trace_3.PID_Int.Out);

            if (Total_Pulse_3 >= 100) {
                RunState_3 = STATE_SLOW_DOWN_3;
                Slow_Down_Steps_3 = 0;
            }
            break;

        case STATE_SLOW_DOWN_3:
            PID_Trace_Update(&PID_Trace_3);

            if (Slow_Down_Steps_3 < SLOW_DOWN_TOTAL_STEPS_3) {
                Slow_Down_Steps_3++;
                uint16_t speed = 350 - (Slow_Down_Steps_3 * 340 / SLOW_DOWN_TOTAL_STEPS_3);
                if (speed < 10) speed = 10;
                Motor_SetSpeed(speed - PID_Trace_3.PID_Int.Out,
                               speed + PID_Trace_3.PID_Int.Out);
            }

            if (Total_Pulse_3 >= 150) {
                RunState_3 = STATE_STOP_3;
                Final_Time_ms_3 = Timer_Get_ms();
            }
            break;

        default:
            break;
    }
}

void Task_3_Exit(void) {
    CAR_SATE = IDLE_STATE;
    Motor_Shake();
}