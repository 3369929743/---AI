#include "ti_msp_dl_config.h"
#include "Task_3.h"
#include "Task_1.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Trace.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Encoder.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\OLED.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Motor.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Pid.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\timer.h"  

extern uint8_t Trace_Value[8];

CAR_STATETypeDef CAR_SATE;

extern uint32_t Start_Time_3;

typedef enum {
    STATE_START_UP_3,     // 0 ~ 40脉冲：速度 15 → 325
    STATE_CRUISE_3,       // 40 ~ 110脉冲：保持 325
    STATE_SLOW_DOWN_3,    // 110 ~ 150脉冲：速度 325 → 0
    STATE_STOP_3          // 达到 150脉冲：停车锁死
} CarRunState_3_t;

CarRunState_3_t RunState_3 = STATE_START_UP_3;
uint8_t Exit_Confirm_3 = 0;
uint8_t Stop_Confirm_3 = 0;
uint8_t Align_Count_3 = 0;

uint32_t Final_Time_ms_3 = 0;   
uint32_t Total_Pulse_3 = 0;  
uint8_t  Ramp_Count_3 = 0;       
uint8_t  Slow_Down_Steps_3 = 0; 
#define SLOW_DOWN_TOTAL_STEPS_3 20  

PID_t PID_Trace_3 = {
    .PID_Float.Kp = 2.6,
    .PID_Float.Ki = 0.0,
    .PID_Float.Kd = 4.5,
    .PID_Int.OutMax = 100,
    .PID_Int.OutMin = -100
};

void Task_3_Init(void) {
    CAR_SATE = TRACE_SATE;
    RunState_3 = STATE_START_UP_3;
    Exit_Confirm_3 = 0;
    Stop_Confirm_3 = 0;
    Align_Count_3 = 0;
    Ramp_Count_3 = 0;
    Slow_Down_Steps_3 = 0;
    PID_Init(&PID_Trace_3);
    Motor_Shake();
    
    Timer_Reset();
    Final_Time_ms_3 = 0;
    Total_Pulse_3 = 0;
}

void Task_3_Loop(void) {
    Trace_GetValue();

    if (RunState_3 == STATE_STOP_3) {
        Motor_Shake();
        PID_Trace_3.PID_Int.Error0 = 0;
        PID_Trace_3.PID_Int.Error1 = 0;
        PID_Trace_3.PID_Int.ErrorInt = 0;
        PID_Trace_3.PID_Int.Out = 0;

        uint32_t end_time = Timer_Get_ms();
        uint32_t raw_time_ms = end_time - Start_Time_3;
        uint32_t real_time_ms = (raw_time_ms * 10000) / 12456;

        if (real_time_ms > 999999) real_time_ms = 999999;
        OLED_ShowString(4, 1, "Time:");
        OLED_ShowNum(4, 5, real_time_ms, 6);
        OLED_ShowString(4, 11, "ms");

        while(1) { }
    }

    if (RunState_3 != STATE_STOP_3) {
        Total_Pulse_3 += Encoder_Get_Distance();
    }

    OLED_ShowNum(3, 11, Total_Pulse_3, 5);

    uint8_t all_black = 1;
    for (uint8_t i = 0; i < 8; i++) {
        if (Trace_Value[i] == 0) {
            all_black = 0; 
            break;
        }
    }

    switch (RunState_3) {
        
        case STATE_START_UP_3:
            if (!all_black) {
                Exit_Confirm_3++;
                if (Exit_Confirm_3 >= 2) {
                    Exit_Confirm_3 = 0;
                }
            } else {
                Exit_Confirm_3 = 0;
            }

            PID_Trace_Update(&PID_Trace_3);

            if (Ramp_Count_3 < 40) { 
                Ramp_Count_3++;
                uint16_t speed = 15 + Ramp_Count_3 * ((325 - 15) / 40);
                if (speed > 325) speed = 325;
                
                if (speed < 50) {
                    Motor_SetSpeed(speed, speed);
                } else {
                    Motor_SetSpeed(speed - PID_Trace_3.PID_Int.Out,
                                   speed + PID_Trace_3.PID_Int.Out);
                }
            }

            if (Total_Pulse_3 >= 40) {
                RunState_3 = STATE_CRUISE_3;
                Ramp_Count_3 = 0;
            }
            break;

        case STATE_CRUISE_3:
            PID_Trace_Update(&PID_Trace_3);
            Motor_SetSpeed(325 - PID_Trace_3.PID_Int.Out,
                           325 + PID_Trace_3.PID_Int.Out);

            if (Total_Pulse_3 >= 110) {
                RunState_3 = STATE_SLOW_DOWN_3;
                Slow_Down_Steps_3 = 0;
            }
            break;

        case STATE_SLOW_DOWN_3:
            PID_Trace_Update(&PID_Trace_3);

            if (Slow_Down_Steps_3 < SLOW_DOWN_TOTAL_STEPS_3) {
                Slow_Down_Steps_3++;
                uint16_t speed = 325 - (Slow_Down_Steps_3 * 325 / SLOW_DOWN_TOTAL_STEPS_3);
                if (speed < 0) speed = 0;
                
                // ===== 【您的需求】速度低于 50 时，彻底停止循迹干预 =====
                if (speed < 50) {
                    Motor_SetSpeed(speed, speed);   // 左右轮完全一致，直行减速
                } else {
                    // 速度 ≥ 50 时，正常循迹
                    int16_t limited_out = PID_Trace_3.PID_Int.Out;
                    int16_t max_correction = (int16_t)(speed * 0.15);
                    if (limited_out > max_correction) limited_out = max_correction;
                    if (limited_out < -max_correction) limited_out = -max_correction;

                    Motor_SetSpeed(speed - limited_out,
                                   speed + limited_out);
                }
            }

            if (Total_Pulse_3 >= 150) {
                RunState_3 = STATE_STOP_3;
                Final_Time_ms_3 = Timer_Get_ms();
            }
            break;

        default:
            break;
    }
}

void Task_3_Exit(void) {
    CAR_SATE = IDLE_STATE;
    Motor_Shake();
}