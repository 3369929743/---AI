#include "ti_msp_dl_config.h"
#include "Task_2.h"
#include "Task_1.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Encoder.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\OLED.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Motor.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Pid.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Trace.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\timer.h"

extern CAR_STATETypeDef CAR_SATE;

typedef enum {
    S1_START_WAIT_2,
    S2_TRACE_RUN_2,
    S3_ALIGN_STOP_2,
    S4_FINISHED_2
} CarRunState_2_t;

CarRunState_2_t RunState_2 = S1_START_WAIT_2;
uint8_t Exit_Confirm_2 = 0;
uint8_t Stop_Confirm_2 = 0;
uint8_t Align_Count_2 = 0;

#define ALIGN_DELAY_10ms_2  28 

uint32_t Final_Time_ms_2 = 0;

PID_t PID_Trace_2 = {
    .PID_Float.Kp = 4.8 ,
    .PID_Float.Ki = 0.0,
    .PID_Float.Kd = 25.0 ,

    .PID_Int.OutMax = 350,
    .PID_Int.OutMin = -350
};

void Task_2_Init(void) {
    CAR_SATE = TRACE_SATE;
    RunState_2 = S1_START_WAIT_2;
    Exit_Confirm_2 = 0;
    Stop_Confirm_2 = 0;
    Align_Count_2 = 0;
    PID_Init(&PID_Trace_2);
    Motor_Shake();
    
    Timer_Reset();
    Final_Time_ms_2 = 0;
}

void Task_2_Loop(void) {
    Trace_GetValue();

    if (RunState_2 == S4_FINISHED_2) {
        uint32_t real_time_ms = (Final_Time_ms_2 * 100) / 1256;
        if (real_time_ms > 999999) real_time_ms = 999999;

        OLED_ShowString(4, 1, "TIME:");
        OLED_ShowNum(4, 4, real_time_ms, 6);
        OLED_ShowString(4, 10, "ms");

        while(1) { }
        return;
    }

    uint8_t all_black = 1;
    for (uint8_t i = 0; i < 8; i++) {
        if (Trace_Value[i] == 0) {
            all_black = 0; 
            break;
        }
    }

    switch (RunState_2) {
        
        case S1_START_WAIT_2:
            Motor_SetSpeed(100, 100);
            if (!all_black) {
                Exit_Confirm_2++;
                if (Exit_Confirm_2 >= 2) {
                    Timer_Reset();
                    RunState_2 = S2_TRACE_RUN_2;
                    Exit_Confirm_2 = 0;
                }
            } else {
                Exit_Confirm_2 = 0;
            }
            break;

        case S2_TRACE_RUN_2:
            PID_Trace_Update(&PID_Trace_2);

            Motor_SetSpeed(350 - PID_Trace_2.PID_Int.Out,
                           350 + PID_Trace_2.PID_Int.Out);

            uint8_t black_count = 0;
            for (uint8_t i = 0; i < 8; i++) {
                if (Trace_Value[i] == 1) {
                    black_count++;
                }
            }

            if (black_count >= 4) {
                Stop_Confirm_2++;
                if (Stop_Confirm_2 >= 2) {
                    Align_Count_2 = 0;
                    RunState_2 = S3_ALIGN_STOP_2;
                    Stop_Confirm_2 = 0;
                }
            } else {
                Stop_Confirm_2 = 0;
            }
            break;

        case S3_ALIGN_STOP_2:
            Motor_SetSpeed(150, 150);
            Align_Count_2++;

            if (Align_Count_2 >= ALIGN_DELAY_10ms_2) {
                Motor_Shake();
                Final_Time_ms_2 = Timer_Get_ms();
                RunState_2 = S4_FINISHED_2;
            }
            break;

        case S4_FINISHED_2:
            break;
    }
}

void Task_2_Exit(void) {
    CAR_SATE = IDLE_STATE;
    Motor_Shake();
}