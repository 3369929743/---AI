#include "ti_msp_dl_config.h"
#include "Task.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\timer.h"
extern uint8_t CurrMode,NextMode;
extern uint8_t KeyNum;
uint8_t Loop_FLAG;

void Task_Init(void){
    OLED_Clear();
    OLED_ShowString(1, 1, "Task_1:");
    OLED_ShowString(2, 1, "Task_2:");
    OLED_ShowString(3, 1, "Task_3:");  /* 新增第三行 */
}

void Task_Index_Loop(void){
    static uint8_t Last_Line;
    if(KeyNum == 1){
        NextMode ++ ;
        OLED_ShowString(Last_Line, 8, "      ");
        OLED_ShowString(NextMode, 8, " *");
        Last_Line = NextMode;
        if( NextMode > 4 ){
            NextMode = 1;
        }
    }
}

void Task_Loop(void){   // 主循环函数
    KeyNum = Key_GetNum();
    Task_Index_Loop();
    if(CurrMode == NextMode){   // 执行当前模式的循环
        if(KeyNum == 2) {
            Loop_FLAG = 1;
            Timer_Reset();       /* 按键启动时清零计时器 */
        }
        if(Loop_FLAG){
            switch (CurrMode) {
                case 1 :
                    Task_1_Loop();
                    break;
                case 2 :
                    Task_2_Loop();
                    break;
                case 3 :              /* 新增任务3 */
                    Task_3_Loop();
                    break;
                default:
                    break;
            }
        }
    }
    else {
        switch (CurrMode) {  // 执行当前模式的退出函数
            case 1 :
                Task_1_Exit();
                break;
            case 2 :
                Task_2_Exit();
                break;
            case 3 :              /* 新增任务3退出 */
                Task_3_Exit();
                break;
            default:
                break;
        }
        switch (NextMode) {  // 执行下个模式的初始化函数
            case 1 :
                Task_1_Init();
                break;
            case 2 :
                Task_2_Init();
                break;
            case 3 :              /* 新增任务3初始化 */
                Task_3_Init();
                break;
            default:
                break;
        }
        Loop_FLAG = 0;
        CurrMode = NextMode;
    }
}