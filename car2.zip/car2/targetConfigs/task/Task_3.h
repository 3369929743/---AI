#ifndef TASK3_H
#define TASK3_H

void Task_3_Init(void);
void Task_3_Loop(void);
void Task_3_Exit(void);

#endif