#ifndef TASK2_H
#define TASK2_H

extern uint8_t Trace_Value[8];
void Task_2_Init(void);
void Task_2_Loop(void);
void Task_2_Exit(void);

#endif