#ifndef __TASK_H
#define __TASK_H

#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\OLED.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Serial.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Delay.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Key.h"
#include "Task_1.h"
#include "Task_2.h"
#include "Task_3.h"   
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\LED.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\JY61P.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Encoder.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\BUZ.h"

void Task_Init(void);
void Task_Loop(void);

#endif