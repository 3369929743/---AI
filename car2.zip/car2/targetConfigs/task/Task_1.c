#include "ti_msp_dl_config.h"
#include "Task_1.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Encoder.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\OLED.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Motor.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Pid.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Trace.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\timer.h"

extern CAR_STATETypeDef CAR_SATE;

typedef enum {
    S1_START_WAIT_1,
    S2_TRACE_RUN_1,
    S3_ALIGN_STOP_1,
    S4_FINISHED_1
} CarRunState_1_t;

CarRunState_1_t RunState_1 = S1_START_WAIT_1;
uint8_t Exit_Confirm_1 = 0;
uint8_t Stop_Confirm_1 = 0;
uint8_t Align_Count_1 = 0;

#define ALIGN_DELAY_10ms_1  25 

uint32_t Final_Time_ms_1 = 0;

PID_t PID_Trace_1 = {
     .PID_Float.Kp = 2.6 ,
    .PID_Float.Ki = 0.0,
    .PID_Float.Kd = 3.0 ,

    .PID_Int.OutMax = 350,
    .PID_Int.OutMin = -350
};

void Task_1_Init(void) {
    CAR_SATE = TRACE_SATE;
    RunState_1 = S1_START_WAIT_1;
    Exit_Confirm_1 = 0;
    Stop_Confirm_1 = 0;
    Align_Count_1 = 0;
    PID_Init(&PID_Trace_1);
    Motor_Shake();
    
    Timer_Reset();
    Final_Time_ms_1 = 0;
}

void Task_1_Loop(void) {
    Trace_GetValue();

    // ===== 显示当前单次脉冲增量 =====
    OLED_ShowNum(3, 11, Encoder_Get_Distance(), 5);

    if (RunState_1 == S4_FINISHED_1) {
        uint32_t real_time_ms = (Final_Time_ms_1 * 100) / 1256;
        if (real_time_ms > 999999) real_time_ms = 999999;

        OLED_ShowString(4, 1, "Time:");
        OLED_ShowNum(4, 5, real_time_ms, 6);
        OLED_ShowString(4, 11, "ms");

        while(1) { }
        return;
    }

    uint8_t all_black = 1;
    for (uint8_t i = 0; i < 8; i++) {
        if (Trace_Value[i] == 0) {
            all_black = 0; 
            break;
        }
    }

    switch (RunState_1) {
        
        case S1_START_WAIT_1:
            // 按下 Key2 后直接启动
            Timer_Reset();
            RunState_1 = S2_TRACE_RUN_1;
            break;

        case S2_TRACE_RUN_1:
            PID_Trace_Update(&PID_Trace_1);

            // ===== 【修改】速度改为 250 =====
            Motor_SetSpeed(250 - PID_Trace_1.PID_Int.Out,
                           250 + PID_Trace_1.PID_Int.Out);

            uint8_t black_count = 0;
            for (uint8_t i = 0; i < 8; i++) {
                if (Trace_Value[i] == 1) {
                    black_count++;
                }
            }

            // ===== 【修改】触发条件改回 4 个及以上 =====
            if (black_count >= 4) {
                Stop_Confirm_1++;
                if (Stop_Confirm_1 >= 2) {
                    Align_Count_1 = 0;
                    RunState_1 = S3_ALIGN_STOP_1;
                    Stop_Confirm_1 = 0;
                }
            } else {
                Stop_Confirm_1 = 0;
            }
            break;

        case S3_ALIGN_STOP_1:
            Motor_SetSpeed(150, 150);
            Align_Count_1++;

            if (Align_Count_1 >= ALIGN_DELAY_10ms_1) {
                Motor_Shake();
                Final_Time_ms_1 = Timer_Get_ms();
                RunState_1 = S4_FINISHED_1;
            }
            break;

        case S4_FINISHED_1:
            break;
    }
}

void Task_1_Exit(void) {
    CAR_SATE = IDLE_STATE;
    Motor_Shake();
}