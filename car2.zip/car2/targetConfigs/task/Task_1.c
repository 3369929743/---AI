
#include "Task_1.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Encoder.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\OLED.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Motor.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Pid.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Trace.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\timer.h"

extern CAR_STATETypeDef CAR_SATE;

// ===== 声明在 Task.c 中定义的启动时间戳 =====
extern uint32_t Start_Time_3;

typedef enum {
    S1_START_WAIT_1,
    S2_TRACE_RUN_1,
    S3_ALIGN_STOP_1,
    S4_FINISHED_1
} CarRunState_1_t;

CarRunState_1_t RunState_1 = S1_START_WAIT_1;
uint8_t Exit_Confirm_1 = 0;
uint8_t Stop_Confirm_1 = 0;
uint8_t Align_Count_1 = 0;

#define ALIGN_DELAY_10ms_1  40 

uint32_t Final_Time_ms_1 = 0;

PID_t PID_Trace_1 = {
    .PID_Float.Kp = 2.6 ,
    .PID_Float.Ki = 0.0,
    .PID_Float.Kd = 5.5 ,
    .PID_Int.OutMax = 350,
    .PID_Int.OutMin = -350
};

uint32_t Total_Pulse_1 = 0;

void Task_1_Init(void) {
    CAR_SATE = TRACE_SATE;
    RunState_1 = S1_START_WAIT_1;
    Exit_Confirm_1 = 0;
    Stop_Confirm_1 = 0;
    Align_Count_1 = 0;
    PID_Init(&PID_Trace_1);
    Motor_Shake();
    
    Timer_Reset();
    Final_Time_ms_1 = 0;
    Total_Pulse_1 = 0;
}

// ===== 辅助函数：计算并显示当前时间 =====
void Display_Current_Time(void) {
    uint32_t end_time = Timer_Get_ms();
    uint32_t raw_time_ms = end_time - Start_Time_3;
    uint32_t real_time_ms = (raw_time_ms * 10000) / 12456;

    if (real_time_ms > 999999) real_time_ms = 999999;

    OLED_ShowString(4, 1, "Time:");
    OLED_ShowNum(4, 5, real_time_ms, 6);
    OLED_ShowString(4, 11, "ms");
}

void Task_1_Loop(void) {
    Trace_GetValue();

    // ===== 累计脉冲显示 =====
    if (RunState_1 != S4_FINISHED_1) {
        Total_Pulse_1 += Encoder_Get_Distance();
    }
    OLED_ShowNum(3, 11, Total_Pulse_1, 5);

    // ===== 行驶过程中实时刷新时间 =====
    if (RunState_1 == S2_TRACE_RUN_1 || RunState_1 == S3_ALIGN_STOP_1) {
        Display_Current_Time();
    }

    if (RunState_1 == S4_FINISHED_1) {
        Motor_Shake();
        PID_Trace_1.PID_Int.Error0 = 0;
        PID_Trace_1.PID_Int.Error1 = 0;
        PID_Trace_1.PID_Int.ErrorInt = 0;
        PID_Trace_1.PID_Int.Out = 0;

        // ===== 停车后显示最终时间 =====
        Display_Current_Time();

        while(1) { }
    }

    uint8_t all_black = 1;
    for (uint8_t i = 0; i < 8; i++) {
        if (Trace_Value[i] == 0) {
            all_black = 0; 
            break;
        }
    }

    switch (RunState_1) {
        
        case S1_START_WAIT_1:
            // 按下 Key2 后直接启动
            Timer_Reset();
            RunState_1 = S2_TRACE_RUN_1;
            break;

        case S2_TRACE_RUN_1:
            PID_Trace_Update(&PID_Trace_1);

            // ===== 【强制执行缓加速】从按键时刻开始，5秒内 0 → 250 =====
            uint16_t base_speed = 250;
            uint32_t elapsed_ms = Timer_Get_ms() - Start_Time_3;

            // 无论传感器状态如何，前5秒都强制加速（如果提前到达250则保持）
            if (elapsed_ms < 5000) {
                base_speed = 0 + (elapsed_ms * (250 - 0) / 5000);
                if (base_speed > 250) base_speed = 250;
            }

            Motor_SetSpeed(base_speed - PID_Trace_1.PID_Int.Out,
                           base_speed + PID_Trace_1.PID_Int.Out);

            uint8_t black_count = 0;
            for (uint8_t i = 0; i < 8; i++) {
                if (Trace_Value[i] == 1) {
                    black_count++;
                }
            }

            // ===== 【一次确认停车】≥4个黑线时，无需二次确认 =====
            if (black_count >= 4) {
                Align_Count_1 = 0;
                RunState_1 = S3_ALIGN_STOP_1;
            }
            break;

        case S3_ALIGN_STOP_1:
            Motor_SetSpeed(100, 100);
            Align_Count_1++;

            if (Align_Count_1 >= ALIGN_DELAY_10ms_1) {
                Motor_Shake();
                Final_Time_ms_1 = Timer_Get_ms();
                RunState_1 = S4_FINISHED_1;
            }
            break;

        case S4_FINISHED_1:
            break;
    }
}

void Task_1_Exit(void) {
    CAR_SATE = IDLE_STATE;
    Motor_Shake();
}