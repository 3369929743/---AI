#include "Task_1.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Encoder.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\OLED.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Motor.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Pid.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Trace.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\timer.h"

extern CAR_STATETypeDef CAR_SATE;
extern uint32_t Start_Time_3;

typedef enum {
    S1_START_WAIT_1,
    S2_TRACE_RUN_1,
    S3_ALIGN_STOP_1,
    S4_FINISHED_1
} CarRunState_1_t;

CarRunState_1_t RunState_1 = S1_START_WAIT_1;
uint8_t Exit_Confirm_1 = 0;
uint8_t Stop_Confirm_1 = 0;
uint8_t Align_Count_1 = 0;

#define ALIGN_DELAY_10ms_1  55

uint32_t Final_Time_ms_1 = 0;

PID_t PID_Trace_1 = {
    .PID_Float.Kp = 1.5,
    .PID_Float.Ki = 0.0,
    .PID_Float.Kd = 5.0,
    .PID_Int.OutMax = 100,
    .PID_Int.OutMin = -100
};

uint32_t Total_Pulse_1 = 0;

void Task_1_Init(void) {
    CAR_SATE = TRACE_SATE;
    RunState_1 = S1_START_WAIT_1;
    Exit_Confirm_1 = 0;
    Stop_Confirm_1 = 0;
    Align_Count_1 = 0;
    PID_Init(&PID_Trace_1);

    Motor_Shake();

    PID_Trace_1.PID_Int.Error0 = 0;
    PID_Trace_1.PID_Int.Error1 = 0;
    PID_Trace_1.PID_Int.ErrorInt = 0;
    PID_Trace_1.PID_Int.Out = 0;
    
    Final_Time_ms_1 = 0;
    Total_Pulse_1 = 0;
}

void Display_Current_Time(void) {
    uint32_t end_time = Timer_Get_ms();
    uint32_t raw_time_ms = end_time - Start_Time_3;
    uint32_t real_time_ms = (raw_time_ms * 10000) / 12456;

    if (real_time_ms > 9999999) real_time_ms = 9999999;

    OLED_ShowString(4, 1, "Time:");
    OLED_ShowNum(4, 5, real_time_ms, 7);
    OLED_ShowString(4, 12, "ms");
}

void Task_1_Loop(void) {
    if (RunState_1 == S1_START_WAIT_1) {
        Motor_Shake();
        Start_Time_3 = Timer_Get_ms();
        RunState_1 = S2_TRACE_RUN_1;
    }

    uint32_t elapsed_ms = Timer_Get_ms() - Start_Time_3;

    // ===== 强制直行保护时间改为 15000ms（15秒） =====
    if (elapsed_ms < 15000) {
        Motor_SetSpeed(50, 50);
        return;
    }

    Trace_GetValue();

    // ===== 时间轴驱动速度 =====
    uint16_t base_speed = 100;

    if (elapsed_ms < 70000) {
        base_speed = 0 + (elapsed_ms * (325 - 0) / 70000);
        if (base_speed > 325) base_speed = 325;
    }
    else if (elapsed_ms < 240000) {
        base_speed = 325;
    }
    else if (elapsed_ms < 270000) {
        base_speed = 325 - ((elapsed_ms - 240000) * (325 - 100) / 30000);
        if (base_speed < 100) base_speed = 100;
    }
    else {
        base_speed = 100;
    }

    OLED_ShowString(3, 1, "su:");
    OLED_ShowNum(3, 4, base_speed, 3);

    if (RunState_1 == S2_TRACE_RUN_1 || RunState_1 == S3_ALIGN_STOP_1) {
        Display_Current_Time();
    }

    if (RunState_1 == S4_FINISHED_1) {
        Motor_Shake();
        PID_Trace_1.PID_Int.Error0 = 0;
        PID_Trace_1.PID_Int.Error1 = 0;
        PID_Trace_1.PID_Int.ErrorInt = 0;
        PID_Trace_1.PID_Int.Out = 0;
        Display_Current_Time();
        while(1) { }
    }

    uint8_t all_black = 1;
    for (uint8_t i = 0; i < 8; i++) {
        if (Trace_Value[i] == 0) {
            all_black = 0; 
            break;
        }
    }

    switch (RunState_1) {
        
        case S2_TRACE_RUN_1:
            PID_Trace_1.PID_Int.Out = 0;
            PID_Trace_Update(&PID_Trace_1);

            Motor_SetSpeed(base_speed - PID_Trace_1.PID_Int.Out,
                           base_speed + PID_Trace_1.PID_Int.Out);

            uint8_t black_count = 0;
            for (uint8_t i = 0; i < 8; i++) {
                if (Trace_Value[i] == 1) {
                    black_count++;
                }
            }

            if (black_count >= 4) {
                Align_Count_1 = 0;
                RunState_1 = S3_ALIGN_STOP_1;
            }
            break;

        case S3_ALIGN_STOP_1:
            Motor_SetSpeed(80, 80);
            Align_Count_1++;

            if (Align_Count_1 >= ALIGN_DELAY_10ms_1) {
                Motor_Shake();
                Final_Time_ms_1 = Timer_Get_ms();
                RunState_1 = S4_FINISHED_1;
            }
            break;

        case S4_FINISHED_1:
            break;
    }
}

void Task_1_Exit(void) {
    CAR_SATE = IDLE_STATE;
    Motor_Shake();
}