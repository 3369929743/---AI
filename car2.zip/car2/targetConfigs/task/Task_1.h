#ifndef TASK1_H
#define TASK1_H

#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Trace.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Pid.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\Motor.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\BUZ.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\LED.h"

typedef enum{
    TRACE_SATE,
    ANVANCE_STATE,
    SHAKE_STATE,
    IDLE_STATE
}CAR_STATETypeDef;

void Task_1_Init(void);
void Task_1_Loop(void);
void Task_1_Exit(void);

#endif