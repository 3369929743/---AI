#ifndef __LED_H
#define __LED_H

typedef enum {
    LED_START,
    LED_END
} LED_StateTypeDef;

void USER_LED_ON(void);
void USER_LED_OFF(void);
void LED_Enable(void);

#endif