#include "ti_msp_dl_config.h"

uint8_t Key_Num;
uint8_t Key_GetState(void){
    if(!DL_GPIO_readPins(GPIO_KEY_PORT,GPIO_KEY_KEY_1_PIN)){
        return 1;
    }
    else if(!DL_GPIO_readPins(GPIO_KEY_PORT,GPIO_KEY_KEY_2_PIN)){
        return 2;
    }
    // else if (!DL_GPIO_readPins(GPIO_KEY_PORT,GPIO_KEY_USER_KEY_PIN)) {
    //     return 3;
    // }
    return 0;
}

uint8_t Key_GetNum(void){
    uint8_t Temp = 0;
    if(Key_Num){
        Temp = Key_Num;
        Key_Num = 0;
        return Temp;
    }
    return 0;
}

void Key_Tick(void){
    static uint8_t CurState,PreState;
    PreState = CurState;
    CurState = Key_GetState();
    if(CurState == 0 && PreState != 0){
        Key_Num = PreState;
    }
}