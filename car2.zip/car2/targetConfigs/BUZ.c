#include "ti_msp_dl_config.h"
#include "BUZ.h"

Buz_StateTypeDef Buz_State;

void Buz_ON(void){
    DL_GPIO_clearPins(GPIO_BUZ_PORT, GPIO_BUZ_BUZ_PIN);
}

void Buz_OFF(void){
    DL_GPIO_setPins(GPIO_BUZ_PORT, GPIO_BUZ_BUZ_PIN);    
}

void BUZ_Enable(void){
    Buz_State = BUZ_START;
    DL_GPIO_clearPins(GPIO_BUZ_PORT, GPIO_BUZ_BUZ_PIN);
}