#include "ti_msp_dl_config.h"
#include "LED.h"

LED_StateTypeDef LED_State;

void USER_LED_OFF(void){
    DL_GPIO_clearPins(GPIO_LEDS_PORT, GPIO_LEDS_USER_LED_PIN);
}

void USER_LED_ON(void){
    DL_GPIO_setPins(GPIO_LEDS_PORT, GPIO_LEDS_USER_LED_PIN);
}

void LED_Enable(void){
    LED_State = LED_START;
    USER_LED_ON();
}