#include "ti_msp_dl_config.h"

static int16_t Last_Error = 0;  // Trace_Error_0表示当前误差，Last用于储存误差值

int8_t Trace_Weight[8] = {-54,-38,-24,-10,10,24,38,54};
uint8_t Trace_Value[8] = {0};
static uint32_t Trace_Pin[8] = {GPIO_TRACE_OUT_1_PIN,GPIO_TRACE_OUT_2_PIN,
                        GPIO_TRACE_OUT_3_PIN,GPIO_TRACE_OUT_4_PIN,
                        GPIO_TRACE_OUT_5_PIN,GPIO_TRACE_OUT_6_PIN,
                        GPIO_TRACE_OUT_7_PIN,GPIO_TRACE_OUT_8_PIN};

static GPIO_Regs * Trace_Port[8] = {GPIO_TRACE_OUT_1_PORT,GPIO_TRACE_OUT_2_PORT,
                        GPIO_TRACE_OUT_3_PORT,GPIO_TRACE_OUT_4_PORT,
                        GPIO_TRACE_OUT_5_PORT,GPIO_TRACE_OUT_6_PORT,
                        GPIO_TRACE_OUT_7_PORT,GPIO_TRACE_OUT_8_PORT};

void Trace_GetValue(void){
    for(uint8_t i=0;i<8;i++){
        if(DL_GPIO_readPins(Trace_Port[i] , Trace_Pin[i] ) != 0){
            Trace_Value[i] = 1 ;
        }
        else {
            Trace_Value[i] = 0 ;
        }
    }
}

int16_t Trace_GetError(void){
    Trace_GetValue();
    int16_t Trace_Error_0 = 0 ; 
    uint8_t Trace_Count = 0;
    for(uint8_t i=0; i<8;i++){
        if(Trace_Value[i]){
            Trace_Count++;
            Trace_Error_0 += Trace_Weight[i];
        }
    }
    if(Trace_Count){
        Last_Error = Trace_Error_0 / Trace_Count;
        return Last_Error;
    }
    else{
        if(Last_Error > 30 ){
            return 80 ;
        }
        else if (Last_Error < - 30) {
            return -80 ;
        }
    }
    return 0;
}

int16_t Trace_Get_LastError(void){
    return Last_Error;
}

uint8_t Juge_White(void){    // 传感器全没检测到线时返回1，有线返回0
    if(DL_GPIO_readPins(GPIO_TRACE_OUT_1_PORT, GPIO_TRACE_OUT_1_PIN) == 0 &&
        DL_GPIO_readPins(GPIO_TRACE_OUT_2_PORT, GPIO_TRACE_OUT_2_PIN) == 0 &&
        DL_GPIO_readPins(GPIO_TRACE_OUT_3_PORT, GPIO_TRACE_OUT_3_PIN) == 0 &&
        DL_GPIO_readPins(GPIO_TRACE_OUT_4_PORT, GPIO_TRACE_OUT_4_PIN) == 0 &&
        DL_GPIO_readPins(GPIO_TRACE_OUT_5_PORT, GPIO_TRACE_OUT_5_PIN) == 0 &&
        DL_GPIO_readPins(GPIO_TRACE_OUT_6_PORT, GPIO_TRACE_OUT_6_PIN) == 0 &&
        DL_GPIO_readPins(GPIO_TRACE_OUT_7_PORT, GPIO_TRACE_OUT_7_PIN) == 0 &&
        DL_GPIO_readPins(GPIO_TRACE_OUT_8_PORT, GPIO_TRACE_OUT_8_PIN) == 0 )
        {
            return 1;
        }
    return 0;
}