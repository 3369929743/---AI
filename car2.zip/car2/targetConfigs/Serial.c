#include "ti_msp_dl_config.h"
#include <stdio.h>
#include <stdarg.h>
#include "OLED.h"

uint8_t RxData,RxDataFLAG;
void Serial_SendByte(uint8_t Byte){
    DL_UART_transmitDataBlocking(SERIAL_INST,Byte);
}

void Serial_SendArray(uint8_t *Data,uint16_t Length){
    for(uint8_t i=0;i<Length;i++){
        Serial_SendByte(Data[i]);
    }
}

void Serial_SendString(char *String){
    for(uint8_t i=0;String[i] != '\0';i++){
        Serial_SendByte(String[i]);
    }
}

void Serial_SendNumber(uint32_t Number,uint32_t Length){
    uint32_t pow = 1;
    for(uint8_t i=0;i<Length-1;i++){
        pow *= 10;
    }
    for(uint8_t i=0;i<Length;i++){
        Serial_SendByte((Number/pow) % 10 + '0');
        pow /= 10;
    }
}

int fputc(int ch, FILE *f){
    Serial_SendByte(ch);
    return ch;
}

void Serial_Printf(char *format,...){
    char String[128];
    va_list args;
    va_start(args, format);
    vsnprintf(String, sizeof(String), format, args);
    va_end(args);
    Serial_SendString(String);
}

uint8_t Serial_GetRxFLAG(void)
{
    if(RxDataFLAG){
        RxDataFLAG = 0;
        return 1;
    }
    return 0;
}

uint8_t Serial_ReceiveData(void){
    return RxData;
}

void SERIAL_INST_IRQHandler(void)
{
    switch (DL_UART_getPendingInterrupt(UART2)) {
        case DL_UART_MAIN_IIDX_RX:
            RxData = DL_UART_receiveData(UART2);
            RxDataFLAG = 1;
            break;
        default:
            break;
    }
}