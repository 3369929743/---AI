#ifndef __WITIMU_H
#define __WITIMU_H

#define ANGBUFFER_SIZE 6

typedef struct{
    int16_t Yaw;
    int16_t Pith;
    int16_t Roll;
}AngleTypeDef;

void JY61P_GetAngle(AngleTypeDef * Data);
void MyI2C_R_Data(uint32_t targetAddr, uint8_t RegAddress, uint8_t *Data, uint16_t Length);
void MyI2C_W_Reg(uint32_t targetAddr, uint8_t RegAddress, int Length , ...);
void JY61P_Unlock(void);
void JY61P_Angle_Reset(void);

#endif