#include "ti_msp_dl_config.h"

void Motor_Advance_Init(void){
     DL_GPIO_setPins(GPIO_MOTOR_BIN1_PORT, GPIO_MOTOR_BIN1_PIN);
    DL_GPIO_clearPins(GPIO_MOTOR_BIN2_PORT, GPIO_MOTOR_BIN2_PIN);

    // ===== A 通道（左电机）在软件里“倒着走”，与右电机同向 =====
    DL_GPIO_clearPins(GPIO_MOTOR_AIN1_PORT, GPIO_MOTOR_AIN1_PIN);
    DL_GPIO_setPins(GPIO_MOTOR_AIN2_PORT, GPIO_MOTOR_AIN2_PIN);
}

void Motor_SetSpeed(uint16_t Left_Speed, uint16_t Right_Speed){
    if(Left_Speed < 0 ) Left_Speed = 0;
    if(Right_Speed < 0) Right_Speed = 0;
    if(Left_Speed > 1000 ) Left_Speed = 1000;
    if(Right_Speed > 1000) Right_Speed = 1000;
    DL_Timer_setCaptureCompareValue(MOTOR_PWM_INST, Left_Speed,  GPIO_MOTOR_PWM_C0_IDX);
    DL_Timer_setCaptureCompareValue(MOTOR_PWM_INST, Right_Speed, GPIO_MOTOR_PWM_C1_IDX);
}

void Motor_Shake(void){
    Motor_SetSpeed(0, 0);
}