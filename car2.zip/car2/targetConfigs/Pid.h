#ifndef __PID_h
#define __PID_h
#include <stdint.h> 
#include "Trace.h"

#define PID_ZOOM 1024  // 2^10,先放大10，输出时再右移10位

typedef struct{
    int32_t Actual;
    int32_t Target;
    int32_t Out;

    int32_t Kp;
    int32_t Ki;
    int32_t Kd;

    int32_t Error0;
    int32_t Error1;
    int32_t ErrorInt;

    // int32_t IntMax;
    // int32_t IntMin;

    int32_t OutMax;
    int32_t OutMin;

}PID_INT_PRARM;

typedef struct {
    float Kp;
    float Ki;
    float Kd;
}PID_FLOAT_PRARM;

typedef struct{
    PID_INT_PRARM PID_Int;
    PID_FLOAT_PRARM PID_Float;
}PID_t;

void PID_Init(PID_t *p);
void PID_Trace_Update(PID_t *p);
void PID_Angle_Update(PID_t *p);

#endif