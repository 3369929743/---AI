#ifndef __TIMER_H
#define __TIMER_H

#include <stdint.h>

// ===== 【关键】声明外部变量，让 main.c 也能用 =====
extern volatile uint32_t timer_ms;

void Timer_Init(void);
uint32_t Timer_Get_ms(void);
void Timer_Reset(void);
void Timer_Delay_ms(uint32_t ms);

#endif