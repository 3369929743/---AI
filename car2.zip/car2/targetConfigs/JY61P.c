#include "ti_msp_dl_config.h"
#include "JY61P.h"
#include "stdio.h"
#include "stdarg.h"

void Wait_I2C_Idle(void){
    uint32_t Time_Out = 0;
    while (!(DL_I2C_getControllerStatus(JY61P_I2C_INST) & DL_I2C_CONTROLLER_STATUS_IDLE)) {
        Time_Out ++ ;
        if(Time_Out > 100000) break;
    }
}

void MyI2C_W_Reg(uint32_t targetAddr, uint8_t RegAddress, int Length , ...){
    uint8_t MyI2C_TxData[Length + 1];   // 数组首位放寄存器地址
    MyI2C_TxData[0] = RegAddress;
    va_list args;
    va_start(args, Length);
    for(uint8_t i=0; i< Length; i++){
        MyI2C_TxData[i + 1] = (uint8_t)va_arg(args,int);
    }
    va_end(args);
    DL_I2C_fillControllerTXFIFO(JY61P_I2C_INST, MyI2C_TxData, sizeof(MyI2C_TxData));
    DL_I2C_startControllerTransfer(JY61P_I2C_INST, targetAddr, DL_I2C_CONTROLLER_DIRECTION_TX, sizeof(MyI2C_TxData));
    Wait_I2C_Idle();
}

void MyI2C_R_Data(uint32_t targetAddr, uint8_t RegAddress, uint8_t *Data, uint16_t Length){
    DL_I2C_fillControllerTXFIFO(JY61P_I2C_INST, &RegAddress, 1);
    DL_I2C_startControllerTransferAdvanced(JY61P_I2C_INST, targetAddr, DL_I2C_CONTROLLER_DIRECTION_TX , 1 ,
                                            DL_I2C_CONTROLLER_START_ENABLE,   // 起始位
                                            DL_I2C_CONTROLLER_STOP_DISABLE ,     // 停止位
                                            DL_I2C_CONTROLLER_ACK_DISABLE );      // 应答位
    uint32_t timeout = 10000;
    while((DL_I2C_getControllerStatus(JY61P_I2C_INST) & DL_I2C_CONTROLLER_STATUS_BUSY) && timeout--);
    if(timeout == 0) return; // I2C超时，直接退出
    DL_I2C_startControllerTransfer(JY61P_I2C_INST, targetAddr, DL_I2C_CONTROLLER_DIRECTION_RX,  Length);
    for(uint8_t i=0; i<Length; i++){
        uint32_t rx_timeout = 100000; // 增加接收超时计数器
        // 等待FIFO有数据，或者超时
        while(DL_I2C_isControllerRXFIFOEmpty(JY61P_I2C_INST)){
            rx_timeout--;
            if(rx_timeout == 0) {
                // 如果超时了，为了防止总线死锁，可以选择发送一个停止信号并退出
                return; 
            }
        }
        Data[i] = DL_I2C_receiveControllerData(JY61P_I2C_INST);
    }
    Wait_I2C_Idle();
}

void JY61P_GetAngle(AngleTypeDef * Data){
    uint8_t Temp[6];
    MyI2C_R_Data(0x50,0x3D,Temp,6);

    // int16_t raw_roll  = (int16_t)((Temp[1] << 8) | Temp[0]);
    // int16_t raw_pitch = (int16_t)((Temp[3] << 8) | Temp[2]);
    int16_t raw_yaw   = (int16_t)((Temp[5] << 8) | Temp[4]);

    // Data->Roll = (int16_t)( ((int32_t)raw_roll  * 1800) / 32768 );  // 这边把陀螺仪角度放大10倍，主要是防止丢失小数的精度，同时又避免了浮点数运算 
    // Data->Pith = (int16_t)( ((int32_t)raw_pitch * 1800) / 32768 );  // 不过目标值也要相应的放大10倍哦
    Data->Yaw  = (int16_t)( ((int32_t)raw_yaw   * 1800) / 32768 );   // 这边只需要用yaw角
}

void JY61P_Unlock(void){
    MyI2C_W_Reg(0x50, 0x69, 2,(uint8_t)(0xB588 >> 0),(uint8_t)(0xB588 >> 8));
}

void JY61P_Angle_Reset(void){
    MyI2C_W_Reg(0x50, 0x01,2 , 0x04 , 0x00);
}
