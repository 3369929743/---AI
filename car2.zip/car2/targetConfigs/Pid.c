#include "ti_msp_dl_config.h"
#include "Pid.h"

void PID_Init(PID_t *p){      // 防止进行过多的浮点数运算，应该要在初始化的时候吧PID参数放大,之后直接调用更新函数就好
    p->PID_Int.Kp = p->PID_Float.Kp * PID_ZOOM ;
    p->PID_Int.Ki = p->PID_Float.Ki * PID_ZOOM ;
    p->PID_Int.Kd = p->PID_Float.Kd * PID_ZOOM ;
}

static inline int32_t PID_DIV(int32_t x){   // 内联函数，只在该文件调用,这个是给定点数四舍五入用的，加精度
    int32_t abs_x = (x > 0) ? x : -x ;
    return (x > 0) ? ((abs_x + PID_ZOOM / 2) >> 10 ) : - ((abs_x + PID_ZOOM / 2) >> 10 ) ; 
}

void PID_Angle_Update(PID_t *p){
    p->PID_Int.Error1 = p->PID_Int.Error0 ;
    p->PID_Int.Error0 = p->PID_Int.Target - p->PID_Int.Actual ;

    if(p->PID_Int.Error0 < -1800 ) p->PID_Int.Error0 += 3600 ;
    if(p->PID_Int.Error0 > 1800 ) p->PID_Int.Error0 -= 3600 ;

    p->PID_Int.ErrorInt += p->PID_Int.Error0 ;
    // if(p->PID_Int.ErrorInt >= p->PID_Int.IntMax) p->PID_Int.ErrorInt = p->PID_Int.IntMax;
    // if(p->PID_Int.ErrorInt <= p->PID_Int.IntMin) p->PID_Int.ErrorInt = p->PID_Int.IntMin;

    p->PID_Int.Out = p->PID_Int.Kp * p->PID_Int.Error0  +
                    p->PID_Int.Ki * p->PID_Int.ErrorInt + 
                    p->PID_Int.Kd * (p->PID_Int.Error0 - p->PID_Int.Error1) ;
    
    p->PID_Int.Out = PID_DIV(p->PID_Int.Out) ;

    if(p->PID_Int.Out >= p->PID_Int.OutMax) p->PID_Int.Out = p->PID_Int.OutMax;
    if(p->PID_Int.Out <= p->PID_Int.OutMin) p->PID_Int.Out = p->PID_Int.OutMin;
}

void PID_Trace_Update(PID_t *p){
    p->PID_Int.Error1 = p->PID_Int.Error0 ;
    p->PID_Int.Error0 = Trace_GetError() ;

    // p->PID_Int.ErrorInt += p->PID_Int.Error0 ;
    // if(p->PID_Int.ErrorInt >= p->PID_Int.IntMax) p->PID_Int.ErrorInt = p->PID_Int.IntMax;
    // if(p->PID_Int.ErrorInt <= p->PID_Int.IntMin) p->PID_Int.ErrorInt = p->PID_Int.IntMin;

    p->PID_Int.Out = p->PID_Int.Kp * p->PID_Int.Error0  +
                    p->PID_Int.Ki * p->PID_Int.ErrorInt + 
                    p->PID_Int.Kd * (p->PID_Int.Error0 - p->PID_Int.Error1) ;
    
    p->PID_Int.Out =  PID_DIV(p->PID_Int.Out) ; // 四舍五入，精度直接翻倍

    if(p->PID_Int.Out >= p->PID_Int.OutMax) p->PID_Int.Out = p->PID_Int.OutMax;
    if(p->PID_Int.Out <= p->PID_Int.OutMin) p->PID_Int.Out = p->PID_Int.OutMin;
}
