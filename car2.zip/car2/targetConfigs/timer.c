#include <stdint.h>
#include "timer.h"

// ===== 【直接写死 CPU 频率】根据您的 MSPM0G3507 实际配置修改 =====
// 如果您不知道是多少，用 32000000 通常没问题
#define CPUCLK_FREQ 32000000  

// ===== SysTick 寄存器地址（ARM Cortex-M 标准） =====
#define SYSTICK_CTRL    (*(volatile uint32_t *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile uint32_t *)0xE000E014)
#define SYSTICK_VAL     (*(volatile uint32_t *)0xE000E018)

// ===== 全局毫秒计数器 =====
volatile uint32_t timer_ms = 0;

void Timer_Init(void) {
    // 1. 停止 SysTick（先关掉，防止乱跑）
    SYSTICK_CTRL = 0;
    
    // 2. 设置重装载值：每 1ms 触发一次中断
    SYSTICK_LOAD = CPUCLK_FREQ / 1000;
    
    // 3. 清零当前值
    SYSTICK_VAL = 0;
    
    // 4. 使能 SysTick：位0=使能计数器，位1=使能中断，位2=使用内核时钟
    // 0x07 = 0b0111
    SYSTICK_CTRL = 0x07;
}

uint32_t Timer_Get_ms(void) {
    return timer_ms;
}

void Timer_Reset(void) {
    timer_ms = 0;
}

void Timer_Delay_ms(uint32_t ms) {
    uint32_t start = Timer_Get_ms();
    while ((Timer_Get_ms() - start) < ms) {
        // 空转等待
    }
}
