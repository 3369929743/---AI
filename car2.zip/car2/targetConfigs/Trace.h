#ifndef __TRACE_H
#define __TRACE_H
#include <stdint.h> 
// ===== 【必须要有这一行，否则其他文件看不见这个数组】 =====
extern uint8_t Trace_Value[8];

int16_t Trace_GetError(void);
uint8_t Juge_White(void);
int16_t Trace_Get_LastError(void);

void Trace_GetValue(void);  

#endif