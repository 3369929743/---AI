#ifndef __ENCODER_H
#define __ENCODER_H
#include <stdint.h> 
#define Filter_BuffSize 6

typedef struct{
    int16_t QEI_Count[Filter_BuffSize];
    uint8_t Filter_BuffIndex;
    int16_t Count_Sum;
}Filter_CountTypedef;

void Encoder_Filter_Reset(void);
uint16_t Encoder_Get_Distance(void);


#endif