#ifndef __MOTOR_H
#define __MOTOR_H

#define MOTOR_BASE_SPEED 200

void Motor_Advance_Init(void);
void Motor_SetSpeed(uint16_t Left_Speed, uint16_t Right_Speed);
void Motor_Shake(void);

#endif
