#include "ti_msp_dl_config.h"
#include "Encoder.h"

uint16_t Motor_Count;
Filter_CountTypedef Filter_Count;


uint16_t Encoder_Get_Pulse(void){
    int16_t Motor_Count = (int16_t)DL_Timer_getTimerCount(MOTOR_QEI_INST) - 1;
    DL_Timer_setTimerCount(MOTOR_QEI_INST,0);
    Motor_Count = -Motor_Count;
    return Motor_Count ;
}

void Encoder_Filter_Reset(void){
    Filter_Count.Count_Sum = 0;
    Filter_Count.Filter_BuffIndex = 0;
    for(uint8_t i=0 ; i< Filter_BuffSize ; i++){
        Filter_Count.QEI_Count[i] = 0;
    }
}

uint16_t Encoder_Get_Distance(void){
    int16_t Temp_Count = Encoder_Get_Pulse();
    Filter_Count.Count_Sum -= Filter_Count.QEI_Count[Filter_Count.Filter_BuffIndex];
    Filter_Count.QEI_Count[Filter_Count.Filter_BuffIndex] = Temp_Count ;
    Filter_Count.Count_Sum += Filter_Count.QEI_Count[Filter_Count.Filter_BuffIndex];
    Filter_Count.Filter_BuffIndex = ( Filter_Count.Filter_BuffIndex + 1 ) % Filter_BuffSize ;
    return Filter_Count.Count_Sum / Filter_BuffSize;
}

