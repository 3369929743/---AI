#ifndef __SERIAL_H
#define __SERIAL_H

void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Data,uint16_t Length);
void Serial_SendString(char *String);
void Serial_SendNumber(uint32_t Number,uint32_t Length);
void Serial_Printf(char *format,...);
uint8_t Serial_GetRxFLAG(void);
uint8_t Serial_ReceiveData(void);

#endif