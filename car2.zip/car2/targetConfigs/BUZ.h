#ifndef __BUZ_H
#define __BUZ_H

typedef enum {
    BUZ_START,
    BUZ_END
}Buz_StateTypeDef;

void BUZ_Enable(void);
void Buz_OFF(void);
void Buz_ON(void);

#endif