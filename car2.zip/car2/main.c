
#include "ti_msp_dl_config.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\task\Task.h"
#include "C:\Users\Hasee\workspace_ccstheia\car2\targetConfigs\timer.h"

uint8_t CurrMode,NextMode;
uint8_t KeyNum;
AngleTypeDef JY61P_Angle;
volatile uint8_t Task_LoopFLAG;
uint16_t Motor_Distance;
extern Buz_StateTypeDef Buz_State;
extern LED_StateTypeDef LED_State;

// ===== 【新增】全局系统时间变量 =====
volatile uint32_t System_Time_ms = 0;
volatile uint32_t Global_Start_Time = 0; 

// ===== 【关键补丁】在这里直接定义 PID_Advance 和 PID_Trace =====
PID_t PID_Advance = {
    .PID_Float.Kp = 0.8,
    .PID_Float.Ki = 0.0,
    .PID_Float.Kd = 0.8,
    .PID_Int.OutMax = 350,
    .PID_Int.OutMin = -350
};

PID_t PID_Trace = {
    .PID_Float.Kp = 1.5,
    .PID_Float.Ki = 0.0,
    .PID_Float.Kd = 1.2,
    .PID_Int.OutMax = 250,
    .PID_Int.OutMin = -250
};

// 这里可以保留您的 extern 声明（如果有的话）
extern PID_t PID_Advance, PID_Trace;

int main(void)
{
    SYSCFG_DL_init();
    Timer_Init();  
    Motor_Advance_Init();
    NVIC_EnableIRQ(SERIAL_INST_INT_IRQN);
    NVIC_EnableIRQ(TIMER_INST_INT_IRQN);
    OLED_Init();
    Task_Init();
    PID_Init(&PID_Advance);
    PID_Init(&PID_Trace); 
    while (1) {
        if(Task_LoopFLAG){
            static uint8_t Loop_Count;
            Task_LoopFLAG = 0;
            Task_Loop();
            JY61P_GetAngle(&JY61P_Angle);
            OLED_ShowSignedNum(2, 10, JY61P_Angle.Yaw, 4);
            if(Buz_State == BUZ_START || LED_State == LED_START){
                Loop_Count++;
                if(Loop_Count >= 25){
                    Loop_Count = 0;
                    Buz_State = BUZ_END;
                    LED_State = LED_END;
                    USER_LED_OFF();
                    Buz_OFF();
                }
            }
        }
    } 
}

void TIMER_INST_IRQHandler(void){
    static uint16_t Time_Count = 0;
    switch(DL_Timer_getPendingInterrupt(TIMER_INST)){
        case DL_TIMER_IIDX_ZERO :
            Time_Count++;
            if(Time_Count >= 10){
                Time_Count = 0;
                Key_Tick();
                Task_LoopFLAG = 1;
                System_Time_ms += 100;
            }
            timer_ms += 10;
            break;
        default:
            break;
    }
}

void SysTick_Handler(void) {
    timer_ms++;
}
