################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"D:/TI/ccs2020/ccs/tools/compiler/ti-cgt-armllvm_4.0.3.LTS/bin/tiarmclang.exe" -c @"syscfg/device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"C:/Users/Hasee/workspace_ccstheia/car2" -I"C:/Users/Hasee/workspace_ccstheia/car2/Debug" -I"D:/TI/ccs2020/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/TI/ccs2020/mspm0_sdk_2_11_00_07/source" -gdwarf-3 -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/Hasee/workspace_ccstheia/car2/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

build-1281633103: ../main.syscfg
	@echo 'Building file: "$<"'
	@echo 'Invoking: SysConfig'
	"D:/TI/ccs2020/sysconfig_1.26.2/sysconfig_cli.bat" --script "C:/Users/Hasee/workspace_ccstheia/car2/main.syscfg" -o "syscfg" -s "D:/TI/ccs2020/mspm0_sdk_2_11_00_07/.metadata/product.json" --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

syscfg/device_linker.cmd: build-1281633103 ../main.syscfg
syscfg/device.opt: build-1281633103
syscfg/device.cmd.genlibs: build-1281633103
syscfg/ti_msp_dl_config.c: build-1281633103
syscfg/ti_msp_dl_config.h: build-1281633103
syscfg/Event.dot: build-1281633103
syscfg: build-1281633103

syscfg/%.o: ./syscfg/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"D:/TI/ccs2020/ccs/tools/compiler/ti-cgt-armllvm_4.0.3.LTS/bin/tiarmclang.exe" -c @"syscfg/device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"C:/Users/Hasee/workspace_ccstheia/car2" -I"C:/Users/Hasee/workspace_ccstheia/car2/Debug" -I"D:/TI/ccs2020/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/TI/ccs2020/mspm0_sdk_2_11_00_07/source" -gdwarf-3 -MMD -MP -MF"syscfg/$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/Hasee/workspace_ccstheia/car2/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

startup_mspm0g350x_ticlang.o: D:/TI/ccs2020/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"D:/TI/ccs2020/ccs/tools/compiler/ti-cgt-armllvm_4.0.3.LTS/bin/tiarmclang.exe" -c @"syscfg/device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"C:/Users/Hasee/workspace_ccstheia/car2" -I"C:/Users/Hasee/workspace_ccstheia/car2/Debug" -I"D:/TI/ccs2020/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/TI/ccs2020/mspm0_sdk_2_11_00_07/source" -gdwarf-3 -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/Hasee/workspace_ccstheia/car2/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


