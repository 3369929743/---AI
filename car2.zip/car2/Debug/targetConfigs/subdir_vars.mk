################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/BUZ.c \
../targetConfigs/Delay.c \
../targetConfigs/Encoder.c \
../targetConfigs/JY61P.c \
../targetConfigs/Key.c \
../targetConfigs/LED.c \
../targetConfigs/Motor.c \
../targetConfigs/OLED.c \
../targetConfigs/Pid.c \
../targetConfigs/Serial.c \
../targetConfigs/Trace.c \
../targetConfigs/timer.c 

C_DEPS += \
./targetConfigs/BUZ.d \
./targetConfigs/Delay.d \
./targetConfigs/Encoder.d \
./targetConfigs/JY61P.d \
./targetConfigs/Key.d \
./targetConfigs/LED.d \
./targetConfigs/Motor.d \
./targetConfigs/OLED.d \
./targetConfigs/Pid.d \
./targetConfigs/Serial.d \
./targetConfigs/Trace.d \
./targetConfigs/timer.d 

OBJS += \
./targetConfigs/BUZ.o \
./targetConfigs/Delay.o \
./targetConfigs/Encoder.o \
./targetConfigs/JY61P.o \
./targetConfigs/Key.o \
./targetConfigs/LED.o \
./targetConfigs/Motor.o \
./targetConfigs/OLED.o \
./targetConfigs/Pid.o \
./targetConfigs/Serial.o \
./targetConfigs/Trace.o \
./targetConfigs/timer.o 

OBJS__QUOTED += \
"targetConfigs\BUZ.o" \
"targetConfigs\Delay.o" \
"targetConfigs\Encoder.o" \
"targetConfigs\JY61P.o" \
"targetConfigs\Key.o" \
"targetConfigs\LED.o" \
"targetConfigs\Motor.o" \
"targetConfigs\OLED.o" \
"targetConfigs\Pid.o" \
"targetConfigs\Serial.o" \
"targetConfigs\Trace.o" \
"targetConfigs\timer.o" 

C_DEPS__QUOTED += \
"targetConfigs\BUZ.d" \
"targetConfigs\Delay.d" \
"targetConfigs\Encoder.d" \
"targetConfigs\JY61P.d" \
"targetConfigs\Key.d" \
"targetConfigs\LED.d" \
"targetConfigs\Motor.d" \
"targetConfigs\OLED.d" \
"targetConfigs\Pid.d" \
"targetConfigs\Serial.d" \
"targetConfigs\Trace.d" \
"targetConfigs\timer.d" 

C_SRCS__QUOTED += \
"../targetConfigs/BUZ.c" \
"../targetConfigs/Delay.c" \
"../targetConfigs/Encoder.c" \
"../targetConfigs/JY61P.c" \
"../targetConfigs/Key.c" \
"../targetConfigs/LED.c" \
"../targetConfigs/Motor.c" \
"../targetConfigs/OLED.c" \
"../targetConfigs/Pid.c" \
"../targetConfigs/Serial.c" \
"../targetConfigs/Trace.c" \
"../targetConfigs/timer.c" 


