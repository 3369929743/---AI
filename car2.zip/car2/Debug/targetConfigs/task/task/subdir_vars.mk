################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
EXE_SRCS += \
../targetConfigs/task/task/17134946071850.exe 

EXE_SRCS__QUOTED += \
"../targetConfigs/task/task/17134946071850.exe" 


