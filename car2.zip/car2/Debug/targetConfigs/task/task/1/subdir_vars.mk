################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/task/task/1/Serial.c \
../targetConfigs/task/task/1/Serial_Packet.c \
../targetConfigs/task/task/1/Serial_Stream.c \
../targetConfigs/task/task/1/Task_Serial.c 

C_DEPS += \
./targetConfigs/task/task/1/Serial.d \
./targetConfigs/task/task/1/Serial_Packet.d \
./targetConfigs/task/task/1/Serial_Stream.d \
./targetConfigs/task/task/1/Task_Serial.d 

OBJS += \
./targetConfigs/task/task/1/Serial.o \
./targetConfigs/task/task/1/Serial_Packet.o \
./targetConfigs/task/task/1/Serial_Stream.o \
./targetConfigs/task/task/1/Task_Serial.o 

OBJS__QUOTED += \
"targetConfigs\task\task\1\Serial.o" \
"targetConfigs\task\task\1\Serial_Packet.o" \
"targetConfigs\task\task\1\Serial_Stream.o" \
"targetConfigs\task\task\1\Task_Serial.o" 

C_DEPS__QUOTED += \
"targetConfigs\task\task\1\Serial.d" \
"targetConfigs\task\task\1\Serial_Packet.d" \
"targetConfigs\task\task\1\Serial_Stream.d" \
"targetConfigs\task\task\1\Task_Serial.d" 

C_SRCS__QUOTED += \
"../targetConfigs/task/task/1/Serial.c" \
"../targetConfigs/task/task/1/Serial_Packet.c" \
"../targetConfigs/task/task/1/Serial_Stream.c" \
"../targetConfigs/task/task/1/Task_Serial.c" 


