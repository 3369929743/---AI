################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
targetConfigs/task/%.o: ../targetConfigs/task/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"D:/TI/ccs2020/ccs/tools/compiler/ti-cgt-armllvm_4.0.3.LTS/bin/tiarmclang.exe" -c @"syscfg/device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"C:/Users/Hasee/workspace_ccstheia/car2" -I"C:/Users/Hasee/workspace_ccstheia/car2/Debug" -I"D:/TI/ccs2020/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/TI/ccs2020/mspm0_sdk_2_11_00_07/source" -gdwarf-3 -MMD -MP -MF"targetConfigs/task/$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/Hasee/workspace_ccstheia/car2/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


