# FIXED

targetConfigs/task/Task_1.o: ../targetConfigs/task/Task_1.c \
 ../targetConfigs/task/Task_1.h \
 C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/Trace.h \
 C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/Pid.h \
 C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/Motor.h \
 C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/BUZ.h \
 C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/LED.h \
 C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/Encoder.h \
 C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/OLED.h \
 C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/timer.h
../targetConfigs/task/Task_1.h:
C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/Trace.h:
C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/Pid.h:
C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/Motor.h:
C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/BUZ.h:
C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/LED.h:
C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/Encoder.h:
C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/OLED.h:
C:/Users/Hasee/workspace_ccstheia/car2/targetConfigs/timer.h:
