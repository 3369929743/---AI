################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/task/Task.c \
../targetConfigs/task/Task_1.c \
../targetConfigs/task/Task_2.c \
../targetConfigs/task/Task_3.c 

C_DEPS += \
./targetConfigs/task/Task.d \
./targetConfigs/task/Task_1.d \
./targetConfigs/task/Task_2.d \
./targetConfigs/task/Task_3.d 

OBJS += \
./targetConfigs/task/Task.o \
./targetConfigs/task/Task_1.o \
./targetConfigs/task/Task_2.o \
./targetConfigs/task/Task_3.o 

OBJS__QUOTED += \
"targetConfigs\task\Task.o" \
"targetConfigs\task\Task_1.o" \
"targetConfigs\task\Task_2.o" \
"targetConfigs\task\Task_3.o" 

C_DEPS__QUOTED += \
"targetConfigs\task\Task.d" \
"targetConfigs\task\Task_1.d" \
"targetConfigs\task\Task_2.d" \
"targetConfigs\task\Task_3.d" 

C_SRCS__QUOTED += \
"../targetConfigs/task/Task.c" \
"../targetConfigs/task/Task_1.c" \
"../targetConfigs/task/Task_2.c" \
"../targetConfigs/task/Task_3.c" 


