/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     80000000
/* Defines for SYSPLL_ERR_01 Workaround */
/* Represent 1.000 as 1000 */
#define FLOAT_TO_INT_SCALE                                               (1000U)
#define FCC_EXPECTED_RATIO                                                  2500
#define FCC_UPPER_BOUND                       (FCC_EXPECTED_RATIO * (1 + 0.003))
#define FCC_LOWER_BOUND                       (FCC_EXPECTED_RATIO * (1 - 0.003))

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);


/* Defines for MOTOR_PWM */
#define MOTOR_PWM_INST                                                     TIMA0
#define MOTOR_PWM_INST_IRQHandler                               TIMA0_IRQHandler
#define MOTOR_PWM_INST_INT_IRQN                                 (TIMA0_INT_IRQn)
#define MOTOR_PWM_INST_CLK_FREQ                                         16000000
/* GPIO defines for channel 0 */
#define GPIO_MOTOR_PWM_C0_PORT                                             GPIOB
#define GPIO_MOTOR_PWM_C0_PIN                                      DL_GPIO_PIN_8
#define GPIO_MOTOR_PWM_C0_IOMUX                                  (IOMUX_PINCM25)
#define GPIO_MOTOR_PWM_C0_IOMUX_FUNC                 IOMUX_PINCM25_PF_TIMA0_CCP0
#define GPIO_MOTOR_PWM_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_MOTOR_PWM_C1_PORT                                             GPIOB
#define GPIO_MOTOR_PWM_C1_PIN                                     DL_GPIO_PIN_12
#define GPIO_MOTOR_PWM_C1_IOMUX                                  (IOMUX_PINCM29)
#define GPIO_MOTOR_PWM_C1_IOMUX_FUNC                 IOMUX_PINCM29_PF_TIMA0_CCP1
#define GPIO_MOTOR_PWM_C1_IDX                                DL_TIMER_CC_1_INDEX




/* Defines for MOTOR_QEI */
#define MOTOR_QEI_INST                                                     TIMG8
#define MOTOR_QEI_INST_IRQHandler                               TIMG8_IRQHandler
#define MOTOR_QEI_INST_INT_IRQN                                 (TIMG8_INT_IRQn)
/* Pin configuration defines for MOTOR_QEI PHA Pin */
#define GPIO_MOTOR_QEI_PHA_PORT                                            GPIOA
#define GPIO_MOTOR_QEI_PHA_PIN                                     DL_GPIO_PIN_7
#define GPIO_MOTOR_QEI_PHA_IOMUX                                 (IOMUX_PINCM14)
#define GPIO_MOTOR_QEI_PHA_IOMUX_FUNC                IOMUX_PINCM14_PF_TIMG8_CCP0
/* Pin configuration defines for MOTOR_QEI PHB Pin */
#define GPIO_MOTOR_QEI_PHB_PORT                                            GPIOB
#define GPIO_MOTOR_QEI_PHB_PIN                                     DL_GPIO_PIN_7
#define GPIO_MOTOR_QEI_PHB_IOMUX                                 (IOMUX_PINCM24)
#define GPIO_MOTOR_QEI_PHB_IOMUX_FUNC                IOMUX_PINCM24_PF_TIMG8_CCP1


/* Defines for TIMER */
#define TIMER_INST                                                       (TIMG7)
#define TIMER_INST_IRQHandler                                   TIMG7_IRQHandler
#define TIMER_INST_INT_IRQN                                     (TIMG7_INT_IRQn)
#define TIMER_INST_LOAD_VALUE                                            (1332U)




/* Defines for JY61P_I2C */
#define JY61P_I2C_INST                                                      I2C0
#define JY61P_I2C_INST_IRQHandler                                I2C0_IRQHandler
#define JY61P_I2C_INST_INT_IRQN                                    I2C0_INT_IRQn
#define JY61P_I2C_BUS_SPEED_HZ                                            100000
#define GPIO_JY61P_I2C_SDA_PORT                                            GPIOA
#define GPIO_JY61P_I2C_SDA_PIN                                    DL_GPIO_PIN_10
#define GPIO_JY61P_I2C_IOMUX_SDA                                 (IOMUX_PINCM21)
#define GPIO_JY61P_I2C_IOMUX_SDA_FUNC                  IOMUX_PINCM21_PF_I2C0_SDA
#define GPIO_JY61P_I2C_SCL_PORT                                            GPIOA
#define GPIO_JY61P_I2C_SCL_PIN                                    DL_GPIO_PIN_11
#define GPIO_JY61P_I2C_IOMUX_SCL                                 (IOMUX_PINCM22)
#define GPIO_JY61P_I2C_IOMUX_SCL_FUNC                  IOMUX_PINCM22_PF_I2C0_SCL


/* Defines for SERIAL */
#define SERIAL_INST                                                        UART0
#define SERIAL_INST_FREQUENCY                                              32768
#define SERIAL_INST_IRQHandler                                  UART0_IRQHandler
#define SERIAL_INST_INT_IRQN                                      UART0_INT_IRQn
#define GPIO_SERIAL_RX_PORT                                                GPIOB
#define GPIO_SERIAL_TX_PORT                                                GPIOB
#define GPIO_SERIAL_RX_PIN                                         DL_GPIO_PIN_1
#define GPIO_SERIAL_TX_PIN                                         DL_GPIO_PIN_0
#define GPIO_SERIAL_IOMUX_RX                                     (IOMUX_PINCM13)
#define GPIO_SERIAL_IOMUX_TX                                     (IOMUX_PINCM12)
#define GPIO_SERIAL_IOMUX_RX_FUNC                      IOMUX_PINCM13_PF_UART0_RX
#define GPIO_SERIAL_IOMUX_TX_FUNC                      IOMUX_PINCM12_PF_UART0_TX
#define SERIAL_BAUD_RATE                                                  (9600)
#define SERIAL_IBRD_33_kHZ_9600_BAUD                                         (1)
#define SERIAL_FBRD_33_kHZ_9600_BAUD                                         (9)





/* Port definition for Pin Group GPIO_LEDS */
#define GPIO_LEDS_PORT                                                   (GPIOB)

/* Defines for USER_LED: GPIOB.22 with pinCMx 50 on package pin 21 */
#define GPIO_LEDS_USER_LED_PIN                                  (DL_GPIO_PIN_22)
#define GPIO_LEDS_USER_LED_IOMUX                                 (IOMUX_PINCM50)
/* Port definition for Pin Group GPIO_BUZ */
#define GPIO_BUZ_PORT                                                    (GPIOA)

/* Defines for BUZ: GPIOA.15 with pinCMx 37 on package pin 8 */
#define GPIO_BUZ_BUZ_PIN                                        (DL_GPIO_PIN_15)
#define GPIO_BUZ_BUZ_IOMUX                                       (IOMUX_PINCM37)
/* Port definition for Pin Group GPIO_OLED */
#define GPIO_OLED_PORT                                                   (GPIOB)

/* Defines for OLED_SDA: GPIOB.24 with pinCMx 52 on package pin 23 */
#define GPIO_OLED_OLED_SDA_PIN                                  (DL_GPIO_PIN_24)
#define GPIO_OLED_OLED_SDA_IOMUX                                 (IOMUX_PINCM52)
/* Defines for OLED_SCL: GPIOB.18 with pinCMx 44 on package pin 15 */
#define GPIO_OLED_OLED_SCL_PIN                                  (DL_GPIO_PIN_18)
#define GPIO_OLED_OLED_SCL_IOMUX                                 (IOMUX_PINCM44)
/* Port definition for Pin Group GPIO_KEY */
#define GPIO_KEY_PORT                                                    (GPIOB)

/* Defines for KEY_1: GPIOB.4 with pinCMx 17 on package pin 52 */
#define GPIO_KEY_KEY_1_PIN                                       (DL_GPIO_PIN_4)
#define GPIO_KEY_KEY_1_IOMUX                                     (IOMUX_PINCM17)
/* Defines for KEY_2: GPIOB.9 with pinCMx 26 on package pin 61 */
#define GPIO_KEY_KEY_2_PIN                                       (DL_GPIO_PIN_9)
#define GPIO_KEY_KEY_2_IOMUX                                     (IOMUX_PINCM26)
/* Defines for OUT_1: GPIOA.25 with pinCMx 55 on package pin 26 */
#define GPIO_TRACE_OUT_1_PORT                                            (GPIOA)
#define GPIO_TRACE_OUT_1_PIN                                    (DL_GPIO_PIN_25)
#define GPIO_TRACE_OUT_1_IOMUX                                   (IOMUX_PINCM55)
/* Defines for OUT_2: GPIOB.25 with pinCMx 56 on package pin 27 */
#define GPIO_TRACE_OUT_2_PORT                                            (GPIOB)
#define GPIO_TRACE_OUT_2_PIN                                    (DL_GPIO_PIN_25)
#define GPIO_TRACE_OUT_2_IOMUX                                   (IOMUX_PINCM56)
/* Defines for OUT_3: GPIOB.20 with pinCMx 48 on package pin 19 */
#define GPIO_TRACE_OUT_3_PORT                                            (GPIOB)
#define GPIO_TRACE_OUT_3_PIN                                    (DL_GPIO_PIN_20)
#define GPIO_TRACE_OUT_3_IOMUX                                   (IOMUX_PINCM48)
/* Defines for OUT_4: GPIOA.14 with pinCMx 36 on package pin 7 */
#define GPIO_TRACE_OUT_4_PORT                                            (GPIOA)
#define GPIO_TRACE_OUT_4_PIN                                    (DL_GPIO_PIN_14)
#define GPIO_TRACE_OUT_4_IOMUX                                   (IOMUX_PINCM36)
/* Defines for OUT_5: GPIOB.17 with pinCMx 43 on package pin 14 */
#define GPIO_TRACE_OUT_5_PORT                                            (GPIOB)
#define GPIO_TRACE_OUT_5_PIN                                    (DL_GPIO_PIN_17)
#define GPIO_TRACE_OUT_5_IOMUX                                   (IOMUX_PINCM43)
/* Defines for OUT_6: GPIOB.19 with pinCMx 45 on package pin 16 */
#define GPIO_TRACE_OUT_6_PORT                                            (GPIOB)
#define GPIO_TRACE_OUT_6_PIN                                    (DL_GPIO_PIN_19)
#define GPIO_TRACE_OUT_6_IOMUX                                   (IOMUX_PINCM45)
/* Defines for OUT_7: GPIOB.21 with pinCMx 49 on package pin 20 */
#define GPIO_TRACE_OUT_7_PORT                                            (GPIOB)
#define GPIO_TRACE_OUT_7_PIN                                    (DL_GPIO_PIN_21)
#define GPIO_TRACE_OUT_7_IOMUX                                   (IOMUX_PINCM49)
/* Defines for OUT_8: GPIOA.30 with pinCMx 5 on package pin 37 */
#define GPIO_TRACE_OUT_8_PORT                                            (GPIOA)
#define GPIO_TRACE_OUT_8_PIN                                    (DL_GPIO_PIN_30)
#define GPIO_TRACE_OUT_8_IOMUX                                    (IOMUX_PINCM5)
/* Defines for AIN1: GPIOA.13 with pinCMx 35 on package pin 6 */
#define GPIO_MOTOR_AIN1_PORT                                             (GPIOA)
#define GPIO_MOTOR_AIN1_PIN                                     (DL_GPIO_PIN_13)
#define GPIO_MOTOR_AIN1_IOMUX                                    (IOMUX_PINCM35)
/* Defines for AIN2: GPIOA.12 with pinCMx 34 on package pin 5 */
#define GPIO_MOTOR_AIN2_PORT                                             (GPIOA)
#define GPIO_MOTOR_AIN2_PIN                                     (DL_GPIO_PIN_12)
#define GPIO_MOTOR_AIN2_IOMUX                                    (IOMUX_PINCM34)
/* Defines for BIN1: GPIOB.26 with pinCMx 57 on package pin 28 */
#define GPIO_MOTOR_BIN1_PORT                                             (GPIOB)
#define GPIO_MOTOR_BIN1_PIN                                     (DL_GPIO_PIN_26)
#define GPIO_MOTOR_BIN1_IOMUX                                    (IOMUX_PINCM57)
/* Defines for BIN2: GPIOA.29 with pinCMx 4 on package pin 36 */
#define GPIO_MOTOR_BIN2_PORT                                             (GPIOA)
#define GPIO_MOTOR_BIN2_PIN                                     (DL_GPIO_PIN_29)
#define GPIO_MOTOR_BIN2_IOMUX                                     (IOMUX_PINCM4)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);
void SYSCFG_DL_MOTOR_PWM_init(void);
void SYSCFG_DL_MOTOR_QEI_init(void);
void SYSCFG_DL_TIMER_init(void);
void SYSCFG_DL_JY61P_I2C_init(void);
void SYSCFG_DL_SERIAL_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
